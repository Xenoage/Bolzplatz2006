-----Bolzplatz 2006----- ----SC Paddelboot----

Team Nr.03 von PsychoFish. 

Zum Spielen die Dateien 

- paddelboot.xml 
- paddelboot-logo.png 
- paddelboot-ads.png 

in den Ordner ".../Bolzplatz 2006/data/teams" kopiern. 
Dann ist das Team in der Gruppe "Alle" anw�hlbar. 

--------------------------------------------------

Team No.03 by PsychoFish. 

Zo play with the team copy 

- paddelboot.xml 
- paddelboot-logo.png 
- paddelboot-ads.png 

to the direction ".../Bolzplatz 2006/data/teams". 
The Team is choosable in the category "All". 


� 2006 PsychoFish | PsychoFish@gmx.de