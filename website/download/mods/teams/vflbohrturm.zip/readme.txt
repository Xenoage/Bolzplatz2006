-----Bolzplatz 2006----- ----VFL Bohrturm----

Team Nr.04 von PsychoFish. 

Zum Spielen die Dateien 

- vflbohrturm.xml 
- vflbohrturm-logo.png 
- vflbohrturm-ads.png 

in den Ordner ".../Bolzplatz 2006/data/teams" kopiern. 
Dann ist das Team in der Gruppe "Alle" anw�hlbar. 

--------------------------------------------------

Team No.04 by PsychoFish. 

Zo play with the team copy 

- vflbohrturm.xml 
- vflbohrturm-logo.png 
- vflbohrturm-ads.png 

to the direction ".../Bolzplatz 2006/data/teams". 
The Team is choosable in the category "All". 


� 2006 PsychoFish | PsychoFish@gmx.de