-----Bolzplatz 2006----- ----FC Sie Will Ja----

Team Nr.02 von PsychoFish f�r das Spiel Bolzplatz 2006. 

Zum Spielen die Dateien 

- siewillja.xml 
- siewillja-logo.png 
- siewillja-ads.png 

in den Ordner .../Bolzplatz 2006/data/teams kopiern. 
Dann ist das Team in der Gruppe "Alle" anw�hlbar. 

--------------------------------------------------

Team No.02 by PsychoFish. 

Zo play with the team copy 

- siewillja.xml 
- siewillja-logo.png 
- siewillja-ads.png 

to the direction ".../Bolzplatz 2006/data/teams". 
The Team is choosable in the category "All". 


� 2006 PsychoFish | PsychoFish@gmx.de