-----Bolzplatz 2006----- ----Germania CHIO----

Team Nr.01 von PsychoFish. 

Zum Spielen die Dateien 

- germania.xml 
- germania-logo.png 
- germania-ads.png 

in den Ordner ".../Bolzplatz 2006/data/teams" kopiern. 
Dann ist das Team in der Gruppe "Alle" anw�hlbar. 

--------------------------------------------------

Team No.01 by PsychoFish. 

Zo play with the team copy 

- germania.xml 
- germania-logo.png 
- germania-ads.png 

to the direction ".../Bolzplatz 2006/data/teams". 
The Team is choosable in the category "All". 


� 2006 PsychoFish | PsychoFish@gmx.de