Kommerzgeil-Arena f�r Bolzplatz 2006 by Eintracht4ever
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Kommerzgeil-Arena for Slam Soccer 2006 by Eintracht4ever


Kopiert den in der zip-Datei enthaltenen "data"-Ordner in euer "Bolzplatz 2006"-Hauptverzeichnis und schon findet ihr das Stadion in der Stadienauswahl.

Just Copy the "data"-folder into your "Slam Soccer 2006" main-directory and you can play in the stadium in the game.

Info: Eintracht4ever@fifa4fans.de
Copyright: Eintracht4ever 2006

