
ID: blstruempfchen
06/2006 by torbart

--------------------------------------------------------------------

:: TEAMNAME: FC Bleiern Str�mpfchen
:: DESCR.  : Schutzgeld, Seebestattungen - alles aus einer Hand
:: Fun-Team fuer Bolzplatz2006, korrupte Spieler ;)

--------------------------------------------------------------------

Kopiere die 3 Dateien nach: 
/data/teams in Deinem Game-Verzeichnis
Im Spiel w�hle: Alle => FC Bleiern Str�mpfchen

--------------------------------------------------------------------

Copy the 3 Files to:
/data/teams in your Game-Dir
In the Game get group "All" => FC Bleiern Str�mpfchen 

--------------------------------------------------------------------


blstruempfchen.xml, blstruempfchen-ads.png, blstruempfchen-logo.png, ReadMe.txt 