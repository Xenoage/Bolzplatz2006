1. FC Frankenland f�r Bolzplatz 2006 by Eintracht4ever
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1. FC Frankenland for Slam Soccer 2006 by Eintracht4ever


Kopiert die Dateien in den ordner "C/Programme/Bolzplatz2006/data/teams" und schon k�nnt ihr das Team in der Kategorie "Alle" in der Mannschaftsauswahl finden.

Just Copy the files into "data/teams" and you can find the team in category "All".

Info: Eintracht4ever@fifa4fans.de
Copyright: Eintracht4ever 2006

