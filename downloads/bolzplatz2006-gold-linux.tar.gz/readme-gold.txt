Java 1.5 or higher is required to run the team editor
and the stadium editor.

These files (gold.jar, teameditor.sh, ...) must be
in the same directory as the game, otherwise the
editors do not run!

You must also overwrite the old
lib/jirr/libirrlicht_wrap.so
with the file in this .tar.gz, otherwise the
stadium editor will crash!

If you have not installed the game yet, download it at
http://www.xenoage.com/slamsoccer2006/