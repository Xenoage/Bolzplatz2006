Java 1.5 or higher is required to run the team editor.

These files (gold.jar, teameditor.sh) must be in the same directory
as the game, otherwise the teameditor does not run!

If you have not installed the game yet, download it at
http://www.xenoage.com/slamsoccer2006/