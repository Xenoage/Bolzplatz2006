/**
 * Bolzplatz 2006
 * Copyright (C) 2006 by Xenoage Software
 * 
 * Attention: This file is part of the Gold-Edition
 * of Bolzplatz 2006 and is not released under the GPL!
 * Ask info@xenoage.com if you want to modify it.
 */
package com.xenoage.bp2k6.tools.stadiumeditor.gui;

import com.xenoage.bp2k6.match.stadium.*;
import com.xenoage.bp2k6.tools.stadiumeditor.StadiumEditor;
import com.xenoage.bp2k6.util.*;
import com.xenoage.bp2k6.util.language.Language;

import java.awt.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.*;
import javax.swing.border.*;

import net.sf.jirr.*;


/**
 * This is the main frame of the
 * stadium editor (developer mode).
 * 
 * @author Andreas Wenger
 */
public class MainFrame
  extends JFrame
  implements ActionListener, WindowListener
{
  //the editor main class
  StadiumEditor editor = null;
  
  //this JFrame: allow "this" for inner classes
  JFrame thisFrame;
  
  //menu components
  JMenuBar mainMenuBar;
  JMenu menuStadium;
  JMenuItem menuStadiumNew, menuStadiumOpen, menuStadiumSaveAs, menuStadiumExit;
  JMenu menuEdit;
  JMenuItem menuEditMoveNorth, menuEditMoveSouth,
    menuEditMoveWest, menuEditMoveEast, menuEditMoveUp, menuEditMoveDown,
    menuEditRotateLeft, menuEditRotateRight,
    menuEditModification, menuEditDelete;
  JMenu menuHelp;
  JMenuItem menuHelpInfo;
  
  //toolbar components
  JToolBar mainToolBar;
  JButton tbbNew, tbbOpen, tbbSaveAs, 
    tbb3DViewDefault, tbb3DViewLeft, tbb3DViewRight, tbb3DViewUp, tbb3DViewDown,
    tbb3DViewZoomIn, tbb3DViewZoomOut;
  JToggleButton tbbShowGrid, tbbAlignGrid, tbbTerrain;
  
  //left bar
  JPanel panelLeft;
  JTabbedPane tabPaneModus;
  JPanel tabStadium;
  JTextField txtStadiumName;
  JLabel lblSpectatorsCountValue;
  JPanel tabStandsContentPanel;
  JLabel lblTerrainIDValue;
  JButton lstProperties;
  JPanel tabGoals;
  JPanel tabLawn;
  JPanel tabScoreboard;
  JPanel tabFloodlight;
  JPanel tabAttractions;
  JPanel tabObjects;
  
  
  //work space (3d view)
  JPanel panelWorkSpace;
  IrrlichtWindow panelIrrlicht;
  boolean irrlichtRunning = false;
  //Thread irrlichtThread;
  
  //gaps between components
  int gapSmall = 5;
  int gapLarge = 10;
  
  
  /**
   * Constructor.
   */
  public MainFrame(StadiumEditor editor)
  {
    Logging.log(Logging.LEVEL_MESSAGES, this, "Loading stadium editor...");
    
    this.editor = editor;
    thisFrame = this;
    this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    //set system look & feel
    //setSystemLookAndFeel();
    //title of stadium editor
    this.setTitle(Language.get("stadiumeditor_title") +
      " - " + Language.get("version") + " " + editor.version);
    //general settings
    this.setIconImage(new ImageIcon("data/images/icons/stadiumeditor.png").getImage());
    this.setSize(800, 600);
    this.setExtendedState(JFrame.MAXIMIZED_BOTH);
    this.addWindowListener(this);
    this.setLayout(new BorderLayout());
    //create menu bar
    createMenuBar();
    //create tool bar
    createToolBar();
    //create left bar
    panelLeft = new JPanel();
    BorderLayout panelLeftLayout = new BorderLayout(5, 5);
    panelLeft.setLayout(panelLeftLayout);
    panelLeft.setBorder(new EmptyBorder(5, 5, 5, 5));
    panelLeft.setSize(200, 200);
    this.add(panelLeft, BorderLayout.WEST);
    //create modus pane and add tabs
    tabPaneModus = new JTabbedPane();
    tabPaneModus.addTab(Language.get("stadium"), createTabStadium());
    tabPaneModus.addTab(Language.get("stands"), createTabStands());
    tabPaneModus.addTab(Language.get("adboards"), createTabAdboards());
    tabPaneModus.addTab(Language.get("goals"), createTabGoals());
    tabPaneModus.addTab(Language.get("lawn"), createTabLawn());
    tabPaneModus.addTab(Language.get("scoreboard"), createTabScoreboard());
    tabPaneModus.addTab(Language.get("floodlight"), createTabFloodlight());
    tabPaneModus.addTab(Language.get("attractions"), createTabAttractions());
    tabPaneModus.addTab(Language.get("objects"), createTabObjects());
    tabPaneModus.addTab(Language.get("terrain"), createTabTerrain());
    tabPaneModus.setSelectedIndex(1);
    panelLeft.add(tabPaneModus, BorderLayout.CENTER);
    //create workspace
    createWorkspace();
    
    Logging.log(Logging.LEVEL_MESSAGES, this, "Stadium editor loaded.");
  }
  
  
  /**
   * Action listener for menu and toolbar events.
   */
  public void actionPerformed(ActionEvent e)
  {
    Object obj = e.getSource();
    //menu
    if (obj == menuStadiumNew)
    {
      newStadium();
    }
    else if (obj == menuStadiumOpen)
    {
      openStadium();
    }
    else if (obj == menuStadiumSaveAs)
    {
      showDialogStadiumSaveAs();
    }
    else if (obj == menuStadiumExit)
    {
      if (showSaveQuestion())
        editor.close();
    }
    else if (obj == menuEditMoveNorth)
    {
      editor.keyPressed(KeyEvent.VK_UP);
    }
    else if (obj == menuEditMoveSouth)
    {
      editor.keyPressed(KeyEvent.VK_DOWN);
    }
    else if (obj == menuEditMoveWest)
    {
      editor.keyPressed(KeyEvent.VK_LEFT);
    }
    else if (obj == menuEditMoveEast)
    {
      editor.keyPressed(KeyEvent.VK_RIGHT);
    }
    else if (obj == menuEditMoveUp)
    {
      editor.keyPressed(KeyEvent.VK_W);
    }
    else if (obj == menuEditMoveDown)
    {
      editor.keyPressed(KeyEvent.VK_Y);
    }
    else if (obj == menuEditRotateLeft)
    {
      editor.keyPressed(KeyEvent.VK_A);
    }
    else if (obj == menuEditRotateRight)
    {
      editor.keyPressed(KeyEvent.VK_S);
    }
    else if (obj == menuEditModification)
    {
      editor.keyPressed(KeyEvent.VK_M);
    }
    else if (obj == menuEditDelete)
    {
      editor.keyPressed(KeyEvent.VK_DELETE);
    }
    else if (obj == menuHelpInfo)
    {
      JOptionPane.showMessageDialog(this,
        Language.get("stadiumeditor_title") + "\n\n" +
        "� 2006 by Andreas Wenger, Xenoage Software",
        Language.get("stadiumeditor_title"),
        JOptionPane.INFORMATION_MESSAGE);
    }
    //toolbar
    else if (obj == tbbNew)
    {
      newStadium();
    }
    else if (obj == tbbOpen)
    {
      openStadium();
    }
    else if (obj == tbbSaveAs)
    {
      showDialogStadiumSaveAs();
    }
    else if (obj == tbbShowGrid)
    {
      panelIrrlicht.setStadiumGridVisible(tbbShowGrid.isSelected());
    }
    else if (obj == tbbAlignGrid)
    {
      editor.setGridAlign(tbbAlignGrid.isSelected());
    }
    else if (obj == tbbTerrain)
    {
      editor.setTerrainVisible(tbbTerrain.isSelected());
    }
    else if (obj == tbb3DViewDefault)
    {
      panelIrrlicht.getCamera().setDefaultPosition();
    }
    else if (obj == tbb3DViewLeft)
    {
      panelIrrlicht.getCamera().left();
    }
    else if (obj == tbb3DViewRight)
    {
      panelIrrlicht.getCamera().right();
    }
    else if (obj == tbb3DViewUp)
    {
      panelIrrlicht.getCamera().up();
    }
    else if (obj == tbb3DViewDown)
    {
      panelIrrlicht.getCamera().down();
    }
    else if (obj == tbb3DViewZoomIn)
    {
      panelIrrlicht.getCamera().zoomIn();
    }
    else if (obj == tbb3DViewZoomOut)
    {
      panelIrrlicht.getCamera().zoomOut();
    }
    panelIrrlicht.repaint();
  }
  
    
  /**
   * Creates the main menu bar.
   */
  private void createMenuBar()
  {
    //create menu bar
    mainMenuBar = new JMenuBar();
    //menu "stadium"
    menuStadium = new JMenu(Language.get("menu_stadium"));
    {
      menuStadiumNew = createMenuItem(Language.get("menu_new"), menuStadium);
      menuStadiumOpen = createMenuItem(Language.get("menu_open"), menuStadium);
      menuStadiumSaveAs = createMenuItem(Language.get("menu_saveas"), menuStadium);
      menuStadium.addSeparator();
      menuStadiumExit = createMenuItem(Language.get("menu_exit"), menuStadium);
    }
    mainMenuBar.add(menuStadium);
    //menu "edit"
    menuEdit = new JMenu(Language.get("menu_edit"));
    {
      menuEditMoveNorth = createMenuItem(Language.get("menu_north"), menuEdit);
      menuEditMoveNorth.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0));
      menuEditMoveSouth = createMenuItem(Language.get("menu_south"), menuEdit);
      menuEditMoveSouth.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0));
      menuEditMoveWest = createMenuItem(Language.get("menu_west"), menuEdit);
      menuEditMoveWest.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0));
      menuEditMoveEast = createMenuItem(Language.get("menu_east"), menuEdit);
      menuEditMoveEast.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0));
      menuEdit.addSeparator();
      menuEditMoveUp = createMenuItem(Language.get("menu_up"), menuEdit);
      menuEditMoveUp.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W, 0));
      menuEditMoveDown = createMenuItem(Language.get("menu_down"), menuEdit);
      menuEditMoveDown.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y, 0));
      menuEdit.addSeparator();
      menuEditRotateLeft = createMenuItem(Language.get("menu_rotateleft"), menuEdit);
      menuEditRotateLeft.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, 0));
      menuEditRotateRight = createMenuItem(Language.get("menu_rotateright"), menuEdit);
      menuEditRotateRight.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, 0));
      menuEdit.addSeparator();
      menuEditModification = createMenuItem(Language.get("menu_modification"), menuEdit);
      menuEditModification.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M, 0));
      menuEdit.addSeparator();
      menuEditDelete = createMenuItem(Language.get("menu_delete"), menuEdit);
      menuEditDelete.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0));
    }
    mainMenuBar.add(menuEdit);
    //menu "help"
    menuHelp = new JMenu(Language.get("menu_help"));
    {
      menuHelpInfo = createMenuItem(Language.get("menu_about"), menuHelp);
    }
    mainMenuBar.add(menuHelp);
    //add menu bar to main frame
    this.setJMenuBar(mainMenuBar);
  }
  
  
  /**
   * Returns a JMenuItem with the given caption on the given
   * parent menu and adds an ActionListener to this.
   */
  private JMenuItem createMenuItem(String caption, JMenu parent)
  {
    JMenuItem ret = new JMenuItem(caption);
    ret.addActionListener(this);
    parent.add(ret);
    return ret;
  }
  
  
  /**
   * Creates the main tool bar.
   */
  private void createToolBar()
  {
    //create tool bar
    mainToolBar = new JToolBar();
    mainToolBar.setFloatable(false);
    //button "new"
    tbbNew = createToolBarButton("new", "Neues Stadion", mainToolBar);
    tbbOpen = createToolBarButton("open", "Stadion �ffnen...", mainToolBar);
    tbbSaveAs = createToolBarButton("saveas", "Stadion speichern unter...", mainToolBar);
    mainToolBar.addSeparator();
    tbbShowGrid = createToolBarToggleButton("showgrid", "Raster anzeigen", mainToolBar, true);
    tbbAlignGrid = createToolBarToggleButton("aligngrid", "Am Raster ausrichten", mainToolBar, true);
    tbbTerrain = createToolBarToggleButton("showterrain", "Terrain anzeigen", mainToolBar, true);
    mainToolBar.addSeparator();
    tbb3DViewDefault = createToolBarButton("defaultview", "3D-Ansicht zur�cksetzen", mainToolBar);
    tbb3DViewLeft = createToolBarButton("left", "3D-Ansicht nach links drehen", mainToolBar);
    tbb3DViewRight = createToolBarButton("right", "3D-Ansicht nach rechts drehen", mainToolBar);
    tbb3DViewUp = createToolBarButton("up", "3D-Ansicht nach oben drehen", mainToolBar);
    tbb3DViewDown = createToolBarButton("down", "3D-Ansicht nach unten drehen", mainToolBar);
    tbb3DViewZoomIn = createToolBarButton("zoomin", "3D-Ansicht hineinzoomen", mainToolBar);
    tbb3DViewZoomOut = createToolBarButton("zoomout", "3D-Ansicht herauszoomen", mainToolBar);
    //add tool bar to main frame
    this.add(mainToolBar, BorderLayout.NORTH);
  }
  
  
  /**
   * Returns a JButton with the given icon id
   * (filename in "data/images/buttons/" without ending ".png")
   * and with the given tooltip text on the given
   * parent toolbar and adds an ActionListener to this.
   */
  private JButton createToolBarButton(String iconID, String tooltip, JToolBar parent)
  {
    Icon icon = null;
    //System.out.println("data/images/buttons/" + iconID + ".png");
    if (iconID != null && iconID.length() > 0)
      icon = new ImageIcon("data/images/buttons/" + iconID + ".png");
    JButton ret = new JButton(icon);
    ret.setToolTipText(tooltip);
    ret.addActionListener(this);
    parent.add(ret);
    return ret;
  }
  
  
  /**
   * Returns a JToggleButton with the given icon id
   * (filename in "data/images/buttons/" without ending ".png")
   * and with the given tooltip text on the given
   * parent toolbar with the given selected value
   * and adds an ActionListener to this.
   */
  private JToggleButton createToolBarToggleButton(String iconID, String tooltip,
    JToolBar parent, boolean selected)
  {
    Icon icon = null;
    if (iconID != null && iconID.length() > 0)
      icon = new ImageIcon("data/images/buttons/" + iconID + ".png");
    JToggleButton ret = new JToggleButton(icon);
    ret.setToolTipText(tooltip);
    ret.setSelected(selected);
    ret.addActionListener(this);
    parent.add(ret);
    return ret;
  }
  
  
  /**
   * Creates the tab page for general stadium information.
   */
  private JPanel createTabStadium()
  {
    JPanel ret = new JPanel();
    JPanel content = new JPanel();
    
    BoxLayout boxLayout = new BoxLayout(content, BoxLayout.Y_AXIS);
    content.setLayout(boxLayout);
    
    JLabel lblStadiumName = new JLabel(Language.get("stadiumname"));
    content.add(lblStadiumName);
    content.add(Box.createRigidArea(new Dimension(0, gapSmall)));
    
    txtStadiumName = new JTextField(Language.get("unnamedstadium"));
    content.add(txtStadiumName);
    content.add(Box.createRigidArea(new Dimension(0, gapLarge)));
    
    JLabel lblSpectatorsCount = new JLabel(Language.get("numberofspectators"));
    content.add(lblSpectatorsCount);
    content.add(Box.createRigidArea(new Dimension(0, gapSmall)));
    
    lblSpectatorsCountValue = new JLabel("0");
    content.add(lblSpectatorsCountValue);
    content.add(Box.createRigidArea(new Dimension(0, gapLarge)));
    
    ret.add(content);
    return ret;
  }
  
  
  /**
   * Creates the tab page for adboards.
   */
  private JPanel createTabAdboards()
  {
    JPanel ret = new JPanel(new BorderLayout());
    ret.setBorder(
      new EmptyBorder(gapLarge, gapLarge, gapLarge, gapLarge));
    
    JPanel content = new JPanel();
    ret.add(content);
    content.setLayout(new GridLayout(4, 1, 0, 5));
    content.add(createAdboardButton(
      "adboard1", "Vereinslogo-Bande"));
    content.add(createAdboardButton(
      "adboard2", "Werbung 1"));
    content.add(createAdboardButton(
      "adboard3", "Werbung 2"));
    content.add(createAdboardButton(
      "adboard4", "Werbung 3"));
    
    return ret;
  }
  
  
  /**
   * Creates the tab page for other stadium objects.
   */
  private JPanel createTabObjects()
  {
    JPanel ret = new JPanel();
    ret.setLayout(new BorderLayout());
    JPanel content = new JPanel();
    content.setBorder(new EmptyBorder(gapLarge, gapLarge, gapLarge, gapLarge));
    
    content.setLayout(new GridLayout(1, 1, 0, gapSmall));
    
    JButton btnAddObject = new JButton(Language.get("addobject..."));
    btnAddObject.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        JFileChooser dlgOpen = new JFileChooser();
        dlgOpen.setCurrentDirectory(new java.io.File("data/meshes/"));
        dlgOpen.addChoosableFileFilter(FileUtils.get3DObjectFilter());
        int ret = dlgOpen.showOpenDialog(thisFrame);
        if (ret == JFileChooser.APPROVE_OPTION)
        {
          String id = dlgOpen.getSelectedFile().getName();
          if (new File("data/meshes/" + id).exists())
            editor.addNewObject(id);
          else
            showMessageBox(
              Language.get("3dobjectmustbeinmeshesdirectory"), true);
        }
      }
    });
    content.add(btnAddObject);

    ret.add(content, BorderLayout.NORTH);
    return ret;
  }
  
  
  /**
   * Creates the tab page for general stadium information.
   */
  private JPanel createTabTerrain()
  {
    JPanel ret = new JPanel();
    ret.setLayout(new BorderLayout());
    JPanel content = new JPanel();
    content.setBorder(new EmptyBorder(gapLarge, gapLarge, gapLarge, gapLarge));
    
    content.setLayout(new GridLayout(4, 1, 0, gapSmall));
    
    JLabel lblTerrainID = new JLabel("Aktuelles Terrain:");
    content.add(lblTerrainID);
    
    lblTerrainIDValue = new JLabel("Kein Terrain");
    content.add(lblTerrainIDValue);
    
    JButton btnTerrainIDLoad = new JButton("Terrain laden...");
    btnTerrainIDLoad.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        JFileChooser dlgOpen = new JFileChooser();
        dlgOpen.setCurrentDirectory(new java.io.File("data/terrains/"));
        dlgOpen.addChoosableFileFilter(FileUtils.getTerrainFilter());
        int ret = dlgOpen.showOpenDialog(thisFrame);
        if (ret == JFileChooser.APPROVE_OPTION)
        {
          String id = FileUtils.getNameWithoutExtension(dlgOpen.getSelectedFile());
          if (new java.io.File("data/terrains/" + id + ".xml").exists())
          {
            editor.setTerrain(id);
          }
          else
          {
            showMessageBox(
              "Invalid file or directory.\nUse only the given terrain directory!", true);
          }
        }
      }
    });
    content.add(btnTerrainIDLoad);
    
    JButton btnTerrainIDDelete = new JButton("Kein Terrain");
    btnTerrainIDDelete.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        editor.setTerrain(null);
      }
    });
    content.add(btnTerrainIDDelete);
    
    ret.add(content, BorderLayout.NORTH);
    return ret;
  }
  
  
  /**
   * Creates the tab page for stands.
   */
  private JPanel createTabStands()
  {
    JPanel ret = new JPanel(new BorderLayout());
    ret.setBorder(
      new EmptyBorder(gapLarge, gapLarge, gapLarge, gapLarge));
    
    //3 panels for the 3 stand stages
    tabStandsContentPanel = new JPanel(new CardLayout());
    JPanel cardStage1 = new JPanel();
    JPanel cardStage2 = new JPanel();
    JPanel cardStage3 = new JPanel();
    tabStandsContentPanel.add(cardStage1, "Stufe 1");
    tabStandsContentPanel.add(cardStage2, "Stufe 2");
    tabStandsContentPanel.add(cardStage3, "Stufe 3");
    ret.add(tabStandsContentPanel, BorderLayout.CENTER);
    
    //create card layout functionality
    JPanel comboBoxPane = new JPanel(new GridLayout(1, 1, 0, 0));
    comboBoxPane.setBorder(new EmptyBorder(0, 0, gapLarge, 0));
    String comboBoxItems[] = { "Stufe 1", "Stufe 2", "Stufe 3" };
    JComboBox cb = new JComboBox(comboBoxItems);
    cb.setEditable(false);
    cb.addItemListener(new ItemListener()
    {
      public void itemStateChanged(ItemEvent evt)
      {
        CardLayout cl = (CardLayout)(tabStandsContentPanel.getLayout());
        cl.show(tabStandsContentPanel, (String)evt.getItem());
      }
    });
    comboBoxPane.add(cb);
    ret.add(comboBoxPane, BorderLayout.NORTH);
    
    //fill stage 1 panel
    cardStage1.setLayout(new GridLayout(3, 1, 0, 5));
    cardStage1.add(createStandButton(
      "stage1_normal", "Gerade (20x10m)"));
    cardStage1.add(createStandButton(
      "stage1_curve", "Kurve (10x10m)"));
    cardStage1.add(createStandButton(
      "stage1_completion", "Abschluss (10x20m)"));
    
    //fill stage 2 panel
    cardStage2.setLayout(new GridLayout(3, 1, 0, 5));
    cardStage2.add(createStandButton(
      "stage2_normal", "Gerade (20x10m)"));
    cardStage2.add(createStandButton(
      "stage2_curve", "Kurve (20x20m)"));
    cardStage2.add(createStandButton(
      "stage2_completion", "Abschluss (10x20m)"));

    //fill stage 3 panel
    cardStage3.setLayout(new GridLayout(3, 1, 0, 5));
    cardStage3.add(createStandButton(
      "stage3_normal", "Gerade (20x10m)"));
    cardStage3.add(createStandButton(
      "stage3_curve", "Kurve (30x30m)"));
    cardStage3.add(createStandButton(
      "stage3_completion", "Abschluss (10x30m)"));
    
    return ret;
  }
  
  
  /**
   * Creates the tab page for goals.
   */
  private JPanel createTabGoals()
  {
    JPanel ret = new JPanel(new BorderLayout());
    ret.setBorder(
      new EmptyBorder(gapLarge, gapLarge, gapLarge, gapLarge));
   
    ret.setLayout(new GridLayout(3, 1, 0, 5));
    ret.add(createGoalsButton(
      "1", Language.get("goal1")));
    ret.add(createGoalsButton(
      "2", Language.get("goal2")));
    ret.add(createGoalsButton(
      "3", Language.get("goal3")));
    
    return ret;
  }
  
  
  /**
   * Creates the tab page for lawn.
   */
  private JPanel createTabLawn()
  {
    JPanel ret = new JPanel(new BorderLayout());
    ret.setBorder(
      new EmptyBorder(gapLarge, gapLarge, gapLarge, gapLarge));
   
    ret.setLayout(new GridLayout(4, 1, 0, 5));
    ret.add(createLawnButton(
      "lawn1", Language.get("lawn_mudfield")));
    ret.add(createLawnButton(
      "lawn2", Language.get("lawn_grassland")));
    ret.add(createLawnButton(
      "lawn3", Language.get("lawn_tendedlawn")));
    ret.add(createLawnButton(
      "lawn4", Language.get("lawn_sod")));
    
    return ret;
  }
  
  
  /**
   * Creates the tab page for scoreboards
   */
  private JPanel createTabScoreboard()
  {
    JPanel ret = new JPanel(new BorderLayout());
    ret.setBorder(
      new EmptyBorder(gapLarge, gapLarge, gapLarge, gapLarge));
    
    JPanel content = new JPanel();
    ret.add(content);
    content.setLayout(new GridLayout(3, 1, 0, 5));
    content.add(createScoreboardButton(
      "1", Language.get("scoreboard1")));
    content.add(createScoreboardButton(
      "2", Language.get("scoreboard2")));
    content.add(createScoreboardButton(
      "3", Language.get("scoreboard3")));
    
    return ret;
  }
  
  
  /**
   * Creates the tab page for floodlight towers.
   */
  private JPanel createTabFloodlight()
  {
    JPanel ret = new JPanel(new BorderLayout());
    ret.setBorder(
      new EmptyBorder(gapLarge, gapLarge, gapLarge, gapLarge));
    
    JPanel content = new JPanel();
    ret.add(content);
    content.setLayout(new GridLayout(3, 1, 0, 5));
    content.add(createFloodlightButton(
      "1", Language.get("floodlight1")));
    content.add(createFloodlightButton(
      "2", Language.get("floodlight2")));
    content.add(createFloodlightButton(
      "3", Language.get("floodlight3")));
    
    return ret;
  }
  
  
  /**
   * Creates the tab page for attractions.
   */
  private JPanel createTabAttractions()
  {
    JPanel ret = new JPanel(new BorderLayout());
    ret.setBorder(
      new EmptyBorder(gapLarge, gapLarge, gapLarge, gapLarge));
    
    JPanel content = new JPanel();
    ret.add(content);
    content.setLayout(new GridLayout(5, 1, 0, 5));
    content.add(createAttractionButton(
      "hotdogstand", Language.get("hotdogstand")));
    content.add(createAttractionButton(
      "bettingoffice", Language.get("bettingoffice")));
    content.add(createAttractionButton(
      "beerbar", Language.get("beerbar")));
    content.add(createAttractionButton(
      "track", Language.get("track")));
    content.add(createAttractionButton(
      "highjump", Language.get("highjump")));
    
    return ret;
  }
  
  
  /**
   * Creates a button for a stand
   */
  private JButton createStandButton(String id, String description)
  {
    JButton ret = new JButton(description,
      new ImageIcon("data/images/stadiumeditor/" + id + ".png"));
    ret.setVerticalTextPosition(AbstractButton.BOTTOM);
    ret.setHorizontalTextPosition(AbstractButton.CENTER);
    ret.setActionCommand(id);
    ret.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        editor.addNewStand(e.getActionCommand());
      }
    });
    return ret;
  }
  
  
  /**
   * Creates a button for an adboard
   */
  private JButton createAdboardButton(String id, String description)
  {
    JButton ret = new JButton(description,
      new ImageIcon("data/images/stadiumeditor/" + id + ".png"));
    ret.setVerticalTextPosition(AbstractButton.BOTTOM);
    ret.setHorizontalTextPosition(AbstractButton.CENTER);
    ret.setActionCommand(id);
    ret.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        editor.addNewAdboard(e.getActionCommand());
      }
    });
    return ret;
  }
  
  
  /**
   * Creates a button for goals.
   */
  private JButton createGoalsButton(String id, String description)
  {
    JButton ret = new JButton(description,
      new ImageIcon("data/images/stadiumeditor/goal" + id + ".png"));
    ret.setVerticalTextPosition(AbstractButton.BOTTOM);
    ret.setHorizontalTextPosition(AbstractButton.CENTER);
    ret.setActionCommand(id);
    ret.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        editor.setGoals(Integer.parseInt(e.getActionCommand()));
      }
    });
    return ret;
  }
  
  
  /**
   * Creates a button for a lawn
   */
  private JButton createLawnButton(String id, String description)
  {
    JButton ret = new JButton(description,
      new ImageIcon("data/images/stadiumeditor/" + id + ".png"));
    ret.setVerticalTextPosition(AbstractButton.BOTTOM);
    ret.setHorizontalTextPosition(AbstractButton.CENTER);
    ret.setActionCommand(id);
    ret.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        editor.setLawn(e.getActionCommand());
      }
    });
    return ret;
  }
  
  
  /**
   * Creates a button for a scoreboard.
   */
  private JButton createScoreboardButton(String id, String description)
  {
    JButton ret = new JButton(description,
      new ImageIcon("data/images/stadiumeditor/scoreboard" + id + ".png"));
    ret.setVerticalTextPosition(AbstractButton.BOTTOM);
    ret.setHorizontalTextPosition(AbstractButton.CENTER);
    ret.setActionCommand(id);
    ret.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        editor.setScoreboard(Integer.parseInt(e.getActionCommand()));
      }
    });
    return ret;
  }
  
  
  /**
   * Creates a button for a floodlight tower.
   */
  private JButton createFloodlightButton(String id, String description)
  {
    JButton ret = new JButton(description,
      new ImageIcon("data/images/stadiumeditor/floodlight" + id + ".png"));
    ret.setVerticalTextPosition(AbstractButton.BOTTOM);
    ret.setHorizontalTextPosition(AbstractButton.CENTER);
    ret.setActionCommand(id);
    ret.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        editor.addNewFloodlight(Integer.parseInt(e.getActionCommand()));
      }
    });
    return ret;
  }
  
  
  /**
   * Creates a button for an attraction.
   */
  private JButton createAttractionButton(String id, String description)
  {
    JButton ret = new JButton(description,
      new ImageIcon("data/images/stadiumeditor/" + id + ".png"));
    ret.setVerticalTextPosition(AbstractButton.BOTTOM);
    ret.setHorizontalTextPosition(AbstractButton.CENTER);
    ret.setActionCommand(id);
    ret.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        editor.addNewAttraction(e.getActionCommand());
      }
    });
    return ret;
  }
  
  
  /**
   * Creates the work space controls (3d view)
   */
  private void createWorkspace()
  {
    panelWorkSpace = new JPanel();
    panelWorkSpace.setLayout(null);
    panelIrrlicht = new IrrlichtWindow(this);
    panelIrrlicht.setSize(760, 570);
    panelIrrlicht.setBackground(new Color(200, 200, 200));
    //create irrlicht device when window is completely loaded
    this.addWindowListener(new WindowAdapter()
    {
      @Override public void windowOpened(WindowEvent e)
      {
        if (!irrlichtRunning)
        {
          irrlichtRunning = true;
          panelIrrlicht.createIrrlichtDevice();
          //mainframe is now completely created.
          editor.mainFrameLoaded();
        }
      }
    });
    panelWorkSpace.add(panelIrrlicht);
    //center 3d window
    panelWorkSpace.addComponentListener(new ComponentAdapter()
    {
      @Override public void componentResized(ComponentEvent e)
      {
        panelIrrlicht.setLocation(
          (panelWorkSpace.getWidth() - panelIrrlicht.getWidth()) / 2,
          (panelWorkSpace.getHeight() - panelIrrlicht.getHeight()) / 2);
      }
    });
    this.add(panelWorkSpace, BorderLayout.CENTER);
  }
  
  
  /**
   * Create new stadium.
   */
  private void newStadium()
  {
    if (showSaveQuestion())
      editor.createNewStadium();
  }
  
  
  /**
   * Opens a stadium.
   */
  private void openStadium()
  {
    if (showSaveQuestion())
      showDialogStadiumOpen();
  }
  
  
  /**
   * Show save question, but only if stadium has
   * some content.
   * @return Returns <code>false</code>, if the user
   * klicked the "cancel" button.
   */
  private boolean showSaveQuestion()
  {
    if (editor.isStadiumEmpty())
      return true;
    int i = JOptionPane.showConfirmDialog(this,
      Language.get("stadiumeditor_savequestion_text"),
      Language.get("stadiumeditor_savequestion_title"),
      JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
    if (i == JOptionPane.YES_OPTION)
      showDialogStadiumSaveAs();
    return (i != JOptionPane.CANCEL_OPTION);
  }
  
  
  /**
   * Show the "open stadium" dialog.
   */
  private void showDialogStadiumOpen()
  {
    JFileChooser dlgOpen = new JFileChooser();
    dlgOpen.setDialogTitle(Language.get("stadiumeditor_openstadium_title"));
    dlgOpen.setCurrentDirectory(new java.io.File("data/stadiums/"));
    dlgOpen.addChoosableFileFilter(FileUtils.getStadiumFilter());
    int ret = dlgOpen.showOpenDialog(this);
    if (ret == JFileChooser.APPROVE_OPTION)
    {
      String id = FileUtils.getNameWithoutExtension(dlgOpen.getSelectedFile());
      if (new java.io.File("data/stadiums/" + id + ".xml").exists())
      {
        editor.loadStadium(id);
      }
      else
      {
        showMessageBox(
          "Invalid file or directory.\nUse only the given stadiums directory!", true);
      }
    }
  }
  
  
  /**
   * Show the "save stadium" dialog.
   */
  private void showDialogStadiumSaveAs()
  {
    JFileChooser dlgSave = new JFileChooser();
    dlgSave.setDialogTitle(Language.get("stadiumeditor_savestadium_title"));
    dlgSave.setCurrentDirectory(new java.io.File("data/stadiums/"));
    dlgSave.addChoosableFileFilter(FileUtils.getStadiumFilter());
    int ret = dlgSave.showSaveDialog(this);
    if (ret == JFileChooser.APPROVE_OPTION)
    {
      String id = FileUtils.getNameWithoutExtension(dlgSave.getSelectedFile());
      //if (new java.io.File("data/stadiums/" + id + ".xml").exists())
      //{
        editor.saveStadium(id);
      //}
    }
  }
  
  
  /**
   * Call this method to fill all controls and
   * the workspace with the information of the
   * current stadium object.
   */
  public void updateStadiumData()
  {
    Stadium stadium = editor.getStadium();
    //terrain
    if (stadium.getTerrain() != null)
      lblTerrainIDValue.setText(stadium.getTerrain().getID());
    else
      lblTerrainIDValue.setText("Kein Terrain"); 
    //stadium info
    txtStadiumName.setText(stadium.getStadiumInfo().getName());
    lblSpectatorsCountValue.setText(String.valueOf(
      stadium.getStadiumInfo().getMaxSpectators()));
  }
  
  
  /**
   * Gets the Irrlicht scene manager.
   */
  public ISceneManager getSceneManager()
  {
    return panelIrrlicht.getSceneManager();
  }
  
  
  /**
   * Gets the Irrlicht video driver.
   */
  public IVideoDriver getVideoDriver()
  {
    return panelIrrlicht.getVideoDriver();
  }
  
  
  /**
   * Repaints the work space window (3d view)
   */
  public void repaint3DView()
  {
    panelIrrlicht.repaint();
  }
  
  
  /**
   * Sets the focus on the work space window (3d view)
   */
  public void focus3DView()
  {
    panelIrrlicht.requestFocus();
  }


  
  public StadiumEditor getEditor()
  {
    return editor;
  }


  public void windowOpened(WindowEvent e)
  {
  }


  public void windowClosing(WindowEvent e)
  {
    if (showSaveQuestion())
      editor.close();
  }


  public void windowClosed(WindowEvent e)
  {
  }


  public void windowIconified(WindowEvent e)
  {
  }


  public void windowDeiconified(WindowEvent e)
  {
  }


  public void windowActivated(WindowEvent e)
  {
  }


  public void windowDeactivated(WindowEvent e)
  {
  }
  
  
  /**
   * Gets the name of the stadium.
   */
  public String getStadiumName()
  {
    return txtStadiumName.getText();
  }
  
  
  private void showMessageBox(String text, boolean warning)
  {
    JOptionPane.showMessageDialog(this, text,
      Language.get("stadiumeditor_title"),
      (warning ? JOptionPane.WARNING_MESSAGE : JOptionPane.INFORMATION_MESSAGE));
  }
  
  
}
